Original tokenizer metadata only; no model weights or executable code.
Source: https://huggingface.co/Qwen/Qwen3.5-35B-A3B/tree/59d61f3ce65a6d9863b86d2e96597125219dc754
Extract to a NEW directory, then run sha256sum -c SHA256SUMS there.
Use prepare_board_tokenizer.py --source-dir EXTRACTED/source --output NEW_PREPARED_DIR.
Run text requests with --tokenizer-dir EXTRACTED/source --text ... --resident --draft-preread.
Preparation needs Python standard library; text admission needs host tokenizers.
Guide: https://github.com/day8reak/qwen3.5-35B-dflash/blob/main/docs/environment-setup.md
